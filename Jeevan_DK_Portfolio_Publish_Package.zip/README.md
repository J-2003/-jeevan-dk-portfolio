# Jeevan DK - Portfolio Website

Your interactive portfolio is ready to publish!

## What's inside:
- index.html - Your complete portfolio (single file, no dependencies)
- Works offline, no build needed

## How to Publish (Free Options):

### Option 1: Netlify (Fastest - 30 seconds)
1. Go to https://app.netlify.com/drop
2. Drag and drop the index.html file
3. Done! You'll get a live URL like https://jeevan-dk-portfolio.netlify.app
4. You can set custom domain later

### Option 2: GitHub Pages (Free forever)
1. Create GitHub repo named jeevan-dk-portfolio
2. Upload index.html
3. Go to Settings > Pages > Deploy from main branch
4. Live at https://yourusername.github.io/jeevan-dk-portfolio/

### Option 3: Vercel (Fast)
1. Go to https://vercel.com/new
2. Upload index.html
3. Deploy

### Option 4: Custom Domain
Buy domain from Namecheap/GoDaddy and point to Netlify/Vercel.

## Features:
- Dark/light mode
- Typing animation
- Interactive skills filter
- Expandable experience timeline
- Project modals
- Contact form (frontend - connect to Formspree for real emails)
- Fully responsive
- ATS-friendly content from your resume

## To connect contact form to real email:
Replace form handler with:
- Formspree.io (free)
- Or EmailJS

## Your info in site:
- Bengaluru, 9380664663, dkjeevan52@gmail.com
- Skills: Python, SQL, Power BI, Firebase, etc.
- Experience: Instawork, Hudl

Built for Lab49 + Honeywell Aerospace applications.
